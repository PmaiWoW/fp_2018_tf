import pygame
import math
import sys
import random
from pygame.locals import *
from variables import *
from visuals import *
from funcs import *


#------Setting up classes------#
class Player:
    
    def __init__(self):
        self.x = playerX
        self.y = playerY
        self.width = playerWidth
        self.height = playerHeight
        self.death = False
        if leftAnim == True:
            self.currentImgRect = leftWalkImgs[walkAnimCounter].get_rect()
        elif rightAnim == True:
            self.currentImgRect = rightWalkImgs[walkAnimCounter].get_rect()
        else:
            self.currentImgRect = playerIdleImg.get_rect()
        
    def draw(self, x, y):
        global walkAnimCounter
        
        if(walkAnimCounter + 1 >= 6):
            walkAnimCounter = 0
        if(leftAnim == True):
            gameDisplay.blit(leftWalkImgs[walkAnimCounter], (self.x, self.y))
            walkAnimCounter += 1
        elif(rightAnim == True):
            gameDisplay.blit(rightWalkImgs[walkAnimCounter], (self.x, self.y))
            walkAnimCounter += 1
        else:
            gameDisplay.blit(playerIdleImg, (self.x, self.y))


    def shieldDraw(self, x, y):
        gameDisplay.blit(shield, (self.x, self.y))
        
    def is_collided_with(self, enemy):
        return self.currentImgRect.colliderect(enemy)

    def is_collided_with(self, bean):
        return self.currentImgRect.colliderect(bean)

    def kill(self):
        self.death = True

        
class Enemy:
    
    def __init__(self):
        self.x = enemyX
        self.y = enemyY
        self.width = enemyWidth
        self.height = enemyHeight
        self.death = False
        self.currentImgRect = enemyImgs[enemyAnimCounter].get_rect()

    def draw(self, enemyX, enemyY):
        global enemyAnimCounter
        
        if(enemyAnimCounter >= 4):
            enemyAnimCounter = 0
            
        gameDisplay.blit(enemyImgs[enemyAnimCounter], (self.x, self.y))
        enemyAnimCounter += 1
        
    def kill(self):
        self.death = True


class CoffeeBean:
    
    def __init__(self):
        self.x = beanX
        self.y = beanY
        self.width = coffeeWidth
        self.height = coffeeHeight
        self.rect = coffeeImg.get_rect()
        self.pickup = False

    def draw(self, beanX, beanY):
        gameDisplay.blit(coffeeImg, (self.x,self.y))
