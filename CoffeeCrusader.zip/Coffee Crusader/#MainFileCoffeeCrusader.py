import pygame
import math
import sys
import random
from pygame.locals import *
from variables import *
from visuals import *
from funcs import *
from classes import *

pygame.init()

#------Begin game------#

player = Player()
enemy = Enemy()
bean = CoffeeBean()


gameDisplay.blit(firstScreen, (0, 0))
pygame.display.update()
waitForPlayerToPressKey()


while not end:
            
    
    if player.is_collided_with(enemy.currentImgRect):
        
        if enemy.x - 50 < player.x < enemy.x + 50 and enemy.y - 50 < player.y < enemy.y + 50:
            if(shieldActive == False):
                player.kill()
                gameDisplay.blit(deathScreen, (0, 0))
                pygame.display.update()
                waitForPlayerToPressKey()
                terminate()
            elif(shieldActive == True):
                enemy.kill()
                enemy.x = -100
                enemy.y = -100
 
    if player.is_collided_with(bean.rect):
        if bean.x - 32 < player.x < bean.x + 32 and bean.y - 32 < player.y < bean.y + 32:
            bean.pickup = True
            gameDisplay.blit(winScreen, (0, 0))
            pygame.display.update()
            waitForPlayerToPressKey()
            terminate()


    shieldActive = False
    redrawGameDisplay()
    
    
    if player.death == False:
        player.draw(player.x, player.y)
        
    if enemy.death == False:
        enemy.draw(enemy.x, enemy.y)
        
    if bean.pickup == False and enemy.death == True:
        bean.draw(bean.x, bean.y)

    for event in pygame.event.get():
            
        if event.type == pygame.QUIT:
            terminate()
    
    
    #------movement------
    controls = pygame.key.get_pressed()
    
    if player.death == False:
        if controls[pygame.K_w] and player.y > speed:
            player.y -= speed
            
        elif controls[pygame.K_a] and player.x > speed:
            player.x -= speed
            leftAnim = True
            rightAnim = False
            
        elif controls[pygame.K_s] and player.y < DISPLAYHEIGHT - player.height:
            player.y += speed
            
        elif controls[pygame.K_d] and player.x < DISPLAYWIDTH - player.width:
            player.x += speed
            leftAnim = False
            rightAnim = True
            
        else:
            rightAnim = False
            leftAnim = False
            walkAnimCounter = 0

        if(controls[pygame.K_q] and controls[pygame.K_w]):
            player.shieldDraw(player.x, player.y - 10)
            shieldActive = True
           
        elif(controls[pygame.K_q] and controls[pygame.K_a]):
            player.shieldDraw(player.x - 10, player.y)
            shieldActive = True
           
        elif(controls[pygame.K_q] and controls[pygame.K_s]):
            player.shieldDraw(player.x, player.y + 10)
            shieldActive = True

        elif(controls[pygame.K_q] and controls[pygame.K_d]):
            player.shieldDraw(player.x + 10, player.y)
            shieldActive = True
            

            
    
    pygame.display.update()
    clock.tick(60)


pygame.quit()
