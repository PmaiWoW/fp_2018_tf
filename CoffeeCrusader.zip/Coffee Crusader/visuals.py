import pygame
import math
import sys
import random
from pygame.locals import *
from variables import *
from funcs import *
from classes import *

#------Setting up the game display and other elements of it------#
gameDisplay = pygame.display.set_mode((DISPLAYWIDTH, DISPLAYHEIGHT))
pygame.display.set_caption('FOR THE LOVE OF COFFEE, DODGE!')
clock = pygame.time.Clock()



#------Loading images------#
bgImg = pygame.image.load('./Assets/Art/bg.png')

winScreen = pygame.image.load('./Assets/Art/winScreen.png')

deathScreen = pygame.image.load('./Assets/Art/deathScreen.png')

firstScreen = pygame.image.load('Assets/Art/firstScreen.png')

playerIdleImg = pygame.image.load('./Assets/Art/CovfefeCrusader.png')

enemyImg = pygame.image.load('./Assets/Art/enemyAnim/enemyAnim1.png')

coffeeImg = pygame.image.load('./Assets/Art/coffeeBean.png')

shield = pygame.image.load('./Assets/Art/aoeAttack.png')

enemyImgs = [pygame.image.load('./Assets/Art/enemyAnim/enemyAnim1.png'),
            pygame.image.load('./Assets/Art/enemyAnim/enemyAnim2.png'),
            pygame.image.load('./Assets/Art/enemyAnim/enemyAnim3.png'),
            pygame.image.load('./Assets/Art/enemyAnim/enemyAnim4.png')]
            
rightWalkImgs = [pygame.image.load('./Assets/Art/walk/rightWalk1.png'),
                 pygame.image.load('./Assets/Art/walk/rightWalk2.png'),
                 pygame.image.load('./Assets/Art/walk/rightWalk3.png'),
                 pygame.image.load('./Assets/Art/walk/rightWalk4.png'),
                 pygame.image.load('./Assets/Art/walk/rightWalk5.png'),
                 pygame.image.load('./Assets/Art/walk/rightWalk6.png')]

leftWalkImgs =  [pygame.image.load('./Assets/Art/walk/leftWalk1.png'),
                 pygame.image.load('./Assets/Art/walk/leftWalk2.png'),
                 pygame.image.load('./Assets/Art/walk/leftWalk3.png'),
                 pygame.image.load('./Assets/Art/walk/leftWalk4.png'),
                 pygame.image.load('./Assets/Art/walk/leftWalk5.png'),
                 pygame.image.load('./Assets/Art/walk/leftWalk6.png')]
