import pygame
import math
import sys
import random
from pygame.locals import *
from variables import *
from visuals import *
from classes import *

        
#------Defining functions------#
def redrawGameDisplay():
    gameDisplay.blit(bgImg, (x,y))


def waitForPlayerToPressKey():
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE: # Pressing ESC quits.
                    terminate()
                return

def terminate():
    pygame.quit()
    sys.exit()
