#------Setting up variables------#
end = False

x, y = 0, 0

playerX, playerY = 0, 384
playerWidth, playerHeight = 64, 64
shieldActive = False

enemyX, enemyY = 1210, 384
enemyWidth, enemyHeight = 64, 64

coffeeWidth, coffeeHeight = 32, 32
beanX, beanY = 970, 250


speed = 10
walkAnimCounter = 0
enemyAnimCounter = 0
leftAnim = False
rightAnim = True

DISPLAYWIDTH = 1280
DISPLAYHEIGHT = 832
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
