Refer�ncias:

Primeiros 3 v�deos de uma playlist no youtube, feitos pelo canal Tech With Tim:
	(Informa��o sobre Movimentos, Anima��es e Sprites consultadas nestes v�deos)
	V�deo #1:https://www.youtube.com/watch?v=i6xMBig-pP4&t=0s&index=2&list=PLzMcBGfZo4-lp3jAExUCewBfMx3UZFkh5
	V�deo #2:https://www.youtube.com/watch?v=2-DNswzCkqk&t=0s&index=3&list=PLzMcBGfZo4-lp3jAExUCewBfMx3UZFkh5
	V�deo #3:https://www.youtube.com/watch?v=UdsNBIzsmlI&t=0s&index=4&list=PLzMcBGfZo4-lp3jAExUCewBfMx3UZFkh5

Discuss�o sobre movimento e colis�es com Tom�s Franco
Discuss�o sobre sprites e anima��es com Afonso Rosa